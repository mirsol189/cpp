﻿// 6_함수1.cpp  28 page ~
// C++함수의 특징 1. 디폴트 파라미터

void foo(int a, int b, int c)
{
}

int main()
{
	foo(1, 2, 3);
	foo(1, 2);
	foo(1);
	foo();
}


