﻿#include <iostream>

int main()
{
	FILE* f = fopen("a.txt", "wt");
}

