﻿// 4_접근지정자    74page ~

struct Bike
{
	int gear;
};

int main()
{
	Bike b;
	b.gear = 10;

}
