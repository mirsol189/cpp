﻿#include <iostream>

class Counter
{
	int count = 0;
public:
	void increment()
	{
		++count;
	}
	int get() { return count; }
};

int main()
{
	Counter c;
	c.increment();
	c.increment();
	c.increment();

	std::cout << c.get() << std::endl;
}
