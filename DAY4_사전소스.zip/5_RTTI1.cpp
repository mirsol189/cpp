#include <iostream>

class Animal
{
	int age;
};
class Dog : public Animal
{
	int color;
};

void foo(Animal* p)
{

}
int main()
{
	Animal a;
	Dog d;

	foo(&a);
	foo(&d);
	



