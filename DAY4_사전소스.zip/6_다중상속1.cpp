class X
{
public:
	int x;
};
class A : public X
{
public:
	int a;
};
class B : public X
{
public:
	int b;
};
class C : public A, public B
{
public:
	int c;
};

int main()
{
	C ccc;
	
}