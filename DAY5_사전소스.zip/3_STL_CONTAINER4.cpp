#include <iostream>

#include <vector>
#include <list>
#include <deque> 

#include <set>	
#include <unordered_set> 

#include <map>			
#include <unordered_map>

#include <string>

int main()
{
	std::set<std::string> s = { "mon", "tue", "wed" };



	
}

