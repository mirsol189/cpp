// 7_STL_ITERATOR1
#include <iostream>
#include <list>
#include <vector>

int main()
{
	int x[5] = { 1,2,3,4,5 };


	std::list<int> s = { 1,2,3,4,5 };
}