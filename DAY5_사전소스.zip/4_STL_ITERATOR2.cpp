#include <iostream>
#include <list>
#include <vector>

int main()
{
	std::list<int> s = { 1,2,3,4,5 };
}

